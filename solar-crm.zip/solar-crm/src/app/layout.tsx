import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SolarCRM',
  description: 'Solar sales CRM — contacts, pipeline, and project tracking',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  )
}
