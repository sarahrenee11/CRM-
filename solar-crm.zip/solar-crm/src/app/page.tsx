'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  supabase,
  fetchContacts,
  createContact,
  updateContact,
  deleteContact,
  type Contact,
} from '@/lib/supabase'

// ─── Constants ────────────────────────────────────────────────────────────────

const STAGES = [
  'New Lead', 'Consultation', 'Site Survey', 'Proposal Sent',
  'Negotiation', 'Permit & Design', 'Installation', 'Completed', 'Lost',
]

const STAGE_COLORS: Record<string, string> = {
  'New Lead': '#f59e0b',
  'Consultation': '#3b82f6',
  'Site Survey': '#8b5cf6',
  'Proposal Sent': '#ec4899',
  'Negotiation': '#f97316',
  'Permit & Design': '#14b8a6',
  'Installation': '#22c55e',
  'Completed': '#10b981',
  'Lost': '#6b7280',
}

const SOURCES = ['Website', 'Referral', 'Door Knock', 'Social Media', 'Google Ad', 'Partner', 'Event', 'Other']
const SYSTEM_SIZES = ['< 5kW', '5–10kW', '10–20kW', '20–50kW', '> 50kW']

const today = new Date().toISOString().slice(0, 10)

// ─── Styles ───────────────────────────────────────────────────────────────────

const inputStyle: React.CSSProperties = {
  width: '100%',
  background: '#1e293b',
  border: '1px solid #334155',
  borderRadius: 8,
  color: '#f1f5f9',
  padding: '9px 12px',
  fontSize: 13,
  outline: 'none',
  boxSizing: 'border-box',
  fontFamily: "'Sora', sans-serif",
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 11,
  color: '#64748b',
  fontWeight: 700,
  letterSpacing: '0.06em',
  marginBottom: 5,
  textTransform: 'uppercase',
}

const btnStyle: React.CSSProperties = {
  background: '#f59e0b',
  color: '#0f172a',
  border: 'none',
  borderRadius: 8,
  padding: '9px 20px',
  fontWeight: 800,
  fontSize: 13,
  cursor: 'pointer',
  letterSpacing: '0.02em',
  fontFamily: "'Sora', sans-serif",
}

// ─── Sub-components ───────────────────────────────────────────────────────────

const formatCurrency = (n: number) => '$' + Number(n).toLocaleString()

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 80 ? '#10b981' : score >= 50 ? '#f59e0b' : '#ef4444'
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: color + '22', borderRadius: 20, padding: '2px 10px' }}>
      <div style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
      <span style={{ fontSize: 12, fontWeight: 700, color }}>{score}</span>
    </div>
  )
}

function StagePill({ stage }: { stage: string }) {
  const color = STAGE_COLORS[stage] || '#888'
  return (
    <span style={{
      display: 'inline-block', fontSize: 11, fontWeight: 700, letterSpacing: '0.04em',
      padding: '3px 10px', borderRadius: 20,
      background: color + '22', color, border: `1px solid ${color}44`, whiteSpace: 'nowrap',
    }}>{stage}</span>
  )
}

function Toast({ message, type }: { message: string; type: 'success' | 'error' }) {
  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24, zIndex: 200,
      background: type === 'success' ? '#10b981' : '#ef4444',
      color: '#fff', borderRadius: 10, padding: '12px 20px',
      fontSize: 13, fontWeight: 700, boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
      animation: 'fadeIn 0.2s ease',
    }}>
      {type === 'success' ? '✓' : '✕'} {message}
    </div>
  )
}

// ─── Modal Form ───────────────────────────────────────────────────────────────

type FormState = Omit<Contact, 'id' | 'created_at'> & { id?: string }

function Modal({
  contact,
  onClose,
  onSave,
  onDelete,
  saving,
}: {
  contact: Contact | null
  onClose: () => void
  onSave: (form: FormState) => void
  onDelete: (id: string) => void
  saving: boolean
}) {
  const [form, setForm] = useState<FormState>(
    contact
      ? { ...contact }
      : {
          name: '', email: '', phone: '', address: '',
          stage: 'New Lead', source: 'Website', system_size: '5–10kW',
          value: 0, notes: '', tasks: [], score: 50,
          last_contact: today,
        }
  )
  const [newTask, setNewTask] = useState('')
  const set = <K extends keyof FormState>(k: K, v: FormState[K]) =>
    setForm(f => ({ ...f, [k]: v }))

  const addTask = () => {
    if (newTask.trim()) {
      set('tasks', [...(form.tasks || []), newTask.trim()])
      setNewTask('')
    }
  }

  return (
    <div
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 16, width: '100%', maxWidth: 640, maxHeight: '90vh', overflowY: 'auto', padding: 28 }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ margin: 0, fontSize: 18, color: '#f1f5f9' }}>
            {contact ? 'Edit Contact' : 'New Contact'}
          </h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#64748b', fontSize: 22, cursor: 'pointer' }}>✕</button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {(['name', 'email', 'phone', 'address'] as const).map(k => (
            <div key={k} style={{ gridColumn: k === 'address' ? '1/-1' : undefined }}>
              <label style={labelStyle}>{k.charAt(0).toUpperCase() + k.slice(1)}</label>
              <input value={form[k] || ''} onChange={e => set(k, e.target.value)} style={inputStyle} />
            </div>
          ))}

          <div>
            <label style={labelStyle}>Stage</label>
            <select value={form.stage} onChange={e => set('stage', e.target.value)} style={inputStyle}>
              {STAGES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Lead Source</label>
            <select value={form.source} onChange={e => set('source', e.target.value)} style={inputStyle}>
              {SOURCES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>System Size</label>
            <select value={form.system_size} onChange={e => set('system_size', e.target.value)} style={inputStyle}>
              {SYSTEM_SIZES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Deal Value ($)</label>
            <input type="number" value={form.value} onChange={e => set('value', +e.target.value)} style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Lead Score (0–100)</label>
            <input type="range" min={0} max={100} value={form.score} onChange={e => set('score', +e.target.value)} style={{ width: '100%', accentColor: '#f59e0b' }} />
            <span style={{ color: '#f59e0b', fontSize: 13, fontWeight: 700 }}>{form.score}</span>
          </div>
          <div>
            <label style={labelStyle}>Last Contact</label>
            <input type="date" value={form.last_contact} onChange={e => set('last_contact', e.target.value)} style={inputStyle} />
          </div>
          <div style={{ gridColumn: '1/-1' }}>
            <label style={labelStyle}>Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={3} style={{ ...inputStyle, resize: 'vertical' }} />
          </div>
          <div style={{ gridColumn: '1/-1' }}>
            <label style={labelStyle}>Tasks / Follow-ups</label>
            <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
              <input
                value={newTask}
                onChange={e => setNewTask(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addTask()}
                placeholder="Add task, press Enter"
                style={{ ...inputStyle, flex: 1 }}
              />
              <button onClick={addTask} style={{ ...btnStyle, padding: '0 14px' }}>+</button>
            </div>
            {(form.tasks || []).map((t, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                <span style={{ flex: 1, color: '#94a3b8', fontSize: 13 }}>• {t}</span>
                <button
                  onClick={() => set('tasks', form.tasks.filter((_, j) => j !== i))}
                  style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 14 }}
                >✕</button>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 22, justifyContent: 'flex-end' }}>
          {contact && (
            <button
              onClick={() => onDelete(contact.id)}
              style={{ ...btnStyle, background: '#ef444422', color: '#ef4444', border: '1px solid #ef444444' }}
              disabled={saving}
            >Delete</button>
          )}
          <button onClick={() => onSave(form)} style={{ ...btnStyle, opacity: saving ? 0.6 : 1 }} disabled={saving}>
            {saving ? 'Saving…' : contact ? 'Save Changes' : 'Add Contact'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────

type View = 'pipeline' | 'list' | 'dashboard' | 'bestpractices'

export default function SolarCRM() {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [view, setView] = useState<View>('pipeline')
  const [modal, setModal] = useState<Contact | 'new' | null>(null)
  const [search, setSearch] = useState('')
  const [filterStage, setFilterStage] = useState('All')
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  // ── Load from Supabase ────────────────────────────────────────────────────

  const loadContacts = useCallback(async () => {
    try {
      const data = await fetchContacts()
      setContacts(data)
    } catch (err) {
      showToast('Failed to load contacts', 'error')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadContacts() }, [loadContacts])

  // ── Real-time subscription ─────────────────────────────────────────────────

  useEffect(() => {
    const channel = supabase
      .channel('contacts-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contacts' }, () => {
        loadContacts()
      })
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [loadContacts])

  // ── Save / Delete ─────────────────────────────────────────────────────────

  const handleSave = async (form: FormState) => {
    setSaving(true)
    try {
      const payload = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        address: form.address,
        stage: form.stage,
        source: form.source,
        system_size: form.system_size,
        value: form.value,
        notes: form.notes,
        score: form.score,
        tasks: form.tasks,
        last_contact: form.last_contact,
      }

      if (form.id) {
        const updated = await updateContact(form.id, payload)
        setContacts(cs => cs.map(c => c.id === form.id ? updated : c))
        showToast('Contact updated')
      } else {
        const created = await createContact(payload)
        setContacts(cs => [created, ...cs])
        showToast('Contact added')
      }
      setModal(null)
    } catch (err) {
      showToast('Save failed — check your connection', 'error')
      console.error(err)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    setSaving(true)
    try {
      await deleteContact(id)
      setContacts(cs => cs.filter(c => c.id !== id))
      setModal(null)
      showToast('Contact deleted')
    } catch (err) {
      showToast('Delete failed', 'error')
      console.error(err)
    } finally {
      setSaving(false)
    }
  }

  // ── Derived data ──────────────────────────────────────────────────────────

  const filtered = contacts.filter(c =>
    (filterStage === 'All' || c.stage === filterStage) &&
    (search === '' || [c.name, c.email, c.phone, c.address].join(' ').toLowerCase().includes(search.toLowerCase()))
  )

  const totalValue = contacts.reduce((s, c) => s + (+c.value || 0), 0)
  const wonValue = contacts.filter(c => c.stage === 'Completed').reduce((s, c) => s + (+c.value || 0), 0)
  const pipelineValue = contacts.filter(c => !['Completed', 'Lost'].includes(c.stage)).reduce((s, c) => s + (+c.value || 0), 0)
  const conversionRate = Math.round((contacts.filter(c => c.stage === 'Completed').length / Math.max(contacts.length, 1)) * 100)

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div style={{ fontFamily: "'Sora', 'Inter', sans-serif", background: '#060d1a', minHeight: '100vh', color: '#f1f5f9' }}>

      {/* Header */}
      <div style={{ background: '#0a1628', borderBottom: '1px solid #1e293b', padding: '0 24px', display: 'flex', alignItems: 'center', height: 56 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginRight: 32 }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: 'linear-gradient(135deg, #f59e0b, #fbbf24)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>☀️</div>
          <span style={{ fontWeight: 800, fontSize: 16, letterSpacing: '-0.02em' }}>SolarCRM</span>
        </div>

        {([['pipeline', 'Pipeline'], ['list', 'Contacts'], ['dashboard', 'Dashboard'], ['bestpractices', 'Best Practices']] as const).map(([v, label]) => (
          <button key={v} onClick={() => setView(v)} style={{
            background: 'none', border: 'none',
            color: view === v ? '#f59e0b' : '#64748b',
            fontWeight: view === v ? 700 : 500, fontSize: 13,
            padding: '0 16px', height: '100%', cursor: 'pointer',
            borderBottom: view === v ? '2px solid #f59e0b' : '2px solid transparent',
            fontFamily: "'Sora', sans-serif", transition: 'all 0.15s',
          }}>{label}</button>
        ))}

        <div style={{ flex: 1 }} />
        <button onClick={() => setModal('new')} style={{ ...btnStyle, fontSize: 12, padding: '7px 16px', display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 16, lineHeight: 1 }}>+</span> New Contact
        </button>
      </div>

      {/* Loading state */}
      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 'calc(100vh - 56px)', gap: 12, color: '#475569' }}>
          <div style={{ width: 20, height: 20, border: '2px solid #334155', borderTopColor: '#f59e0b', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
          Loading contacts…
          <style>{`@keyframes spin { to { transform: rotate(360deg) } } @keyframes fadeIn { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }`}</style>
        </div>
      )}

      {!loading && (
        <div style={{ padding: 24 }}>

          {/* ── PIPELINE ── */}
          {view === 'pipeline' && (
            <div>
              <h1 style={{ margin: '0 0 20px', fontSize: 22, fontWeight: 800 }}>Sales Pipeline</h1>
              <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 12 }}>
                {STAGES.map(stage => {
                  const stageContacts = contacts.filter(c => c.stage === stage)
                  const stageValue = stageContacts.reduce((s, c) => s + (+c.value || 0), 0)
                  return (
                    <div key={stage} style={{ minWidth: 200, maxWidth: 220, flex: '0 0 200px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                        <span style={{ fontSize: 11, fontWeight: 700, color: STAGE_COLORS[stage], letterSpacing: '0.05em', textTransform: 'uppercase' }}>{stage}</span>
                        <span style={{ fontSize: 11, color: '#475569', fontWeight: 600 }}>{stageContacts.length}</span>
                      </div>
                      {stageValue > 0 && <div style={{ fontSize: 11, color: '#64748b', marginBottom: 8 }}>{formatCurrency(stageValue)}</div>}
                      {stageContacts.map(c => (
                        <div
                          key={c.id}
                          onClick={() => setModal(c)}
                          style={{
                            background: '#0f172a', border: '1px solid #1e293b', borderRadius: 10,
                            padding: '12px 14px', marginBottom: 8, cursor: 'pointer',
                            borderLeft: `3px solid ${STAGE_COLORS[c.stage] || '#888'}`,
                            transition: 'background 0.15s',
                          }}
                          onMouseEnter={e => (e.currentTarget.style.background = '#1e293b')}
                          onMouseLeave={e => (e.currentTarget.style.background = '#0f172a')}
                        >
                          <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{c.name}</div>
                          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 6 }}>{c.system_size} · {c.source}</div>
                          {c.value > 0 && <div style={{ fontSize: 12, color: '#f59e0b', fontWeight: 700 }}>{formatCurrency(c.value)}</div>}
                          {c.tasks?.length > 0 && (
                            <div style={{ marginTop: 6, fontSize: 10, color: '#94a3b8', background: '#1e293b', borderRadius: 6, padding: '3px 8px' }}>
                              📋 {c.tasks.length} task{c.tasks.length > 1 ? 's' : ''}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* ── CONTACTS LIST ── */}
          {view === 'list' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, gap: 12, flexWrap: 'wrap' }}>
                <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>Contacts <span style={{ fontSize: 14, color: '#475569', fontWeight: 500 }}>({filtered.length})</span></h1>
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                  <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search…" style={{ ...inputStyle, width: 220 }} />
                  <select value={filterStage} onChange={e => setFilterStage(e.target.value)} style={{ ...inputStyle, width: 160 }}>
                    <option>All</option>
                    {STAGES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid #1e293b' }}>
                      {['Name', 'Stage', 'System', 'Value', 'Score', 'Last Contact', 'Tasks', ''].map(h => (
                        <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 11, color: '#475569', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(c => (
                      <tr
                        key={c.id}
                        style={{ borderBottom: '1px solid #1e293b', transition: 'background 0.1s' }}
                        onMouseEnter={e => (e.currentTarget.style.background = '#1e293b')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                      >
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ fontWeight: 700, fontSize: 13 }}>{c.name}</div>
                          <div style={{ fontSize: 11, color: '#64748b' }}>{c.email}</div>
                        </td>
                        <td style={{ padding: '12px 16px' }}><StagePill stage={c.stage} /></td>
                        <td style={{ padding: '12px 16px', fontSize: 12, color: '#94a3b8' }}>{c.system_size}</td>
                        <td style={{ padding: '12px 16px', fontSize: 13, color: '#f59e0b', fontWeight: 700 }}>{c.value ? formatCurrency(c.value) : '—'}</td>
                        <td style={{ padding: '12px 16px' }}><ScoreBadge score={c.score} /></td>
                        <td style={{ padding: '12px 16px', fontSize: 12, color: '#64748b' }}>{c.last_contact}</td>
                        <td style={{ padding: '12px 16px', fontSize: 12, color: c.tasks?.length ? '#f59e0b' : '#334155' }}>
                          {c.tasks?.length ? `${c.tasks.length} task${c.tasks.length > 1 ? 's' : ''}` : '—'}
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <button onClick={() => setModal(c)} style={{ background: '#1e293b', border: '1px solid #334155', color: '#94a3b8', borderRadius: 6, padding: '5px 12px', cursor: 'pointer', fontSize: 12 }}>Edit</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filtered.length === 0 && (
                  <div style={{ padding: 40, textAlign: 'center', color: '#475569' }}>
                    {contacts.length === 0 ? 'No contacts yet — add your first lead!' : 'No contacts match your filters.'}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── DASHBOARD ── */}
          {view === 'dashboard' && (
            <div>
              <h1 style={{ margin: '0 0 20px', fontSize: 22, fontWeight: 800 }}>Dashboard</h1>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px,1fr))', gap: 16, marginBottom: 28 }}>
                {[
                  { label: 'Total Contacts', value: contacts.length, color: '#3b82f6' },
                  { label: 'Pipeline Value', value: formatCurrency(pipelineValue), color: '#f59e0b' },
                  { label: 'Won Revenue', value: formatCurrency(wonValue), color: '#10b981' },
                  { label: 'Conversion Rate', value: conversionRate + '%', color: '#8b5cf6' },
                ].map(card => (
                  <div key={card.label} style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, padding: 20 }}>
                    <div style={{ fontSize: 11, color: '#64748b', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 8 }}>{card.label}</div>
                    <div style={{ fontSize: 26, fontWeight: 800, color: card.color }}>{card.value}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, padding: 20 }}>
                  <h3 style={{ margin: '0 0 16px', fontSize: 14, fontWeight: 700, color: '#94a3b8' }}>Pipeline by Stage</h3>
                  {STAGES.map(stage => {
                    const count = contacts.filter(c => c.stage === stage).length
                    const pct = Math.round((count / Math.max(contacts.length, 1)) * 100)
                    return (
                      <div key={stage} style={{ marginBottom: 10 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                          <span style={{ color: '#94a3b8' }}>{stage}</span>
                          <span style={{ color: STAGE_COLORS[stage], fontWeight: 700 }}>{count}</span>
                        </div>
                        <div style={{ height: 6, background: '#1e293b', borderRadius: 3, overflow: 'hidden' }}>
                          <div style={{ width: pct + '%', height: '100%', background: STAGE_COLORS[stage], borderRadius: 3, transition: 'width 0.5s' }} />
                        </div>
                      </div>
                    )
                  })}
                </div>

                <div style={{ background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, padding: 20 }}>
                  <h3 style={{ margin: '0 0 16px', fontSize: 14, fontWeight: 700, color: '#94a3b8' }}>Lead Sources</h3>
                  {SOURCES.map(src => {
                    const count = contacts.filter(c => c.source === src).length
                    if (!count) return null
                    const pct = Math.round((count / contacts.length) * 100)
                    return (
                      <div key={src} style={{ marginBottom: 10 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                          <span style={{ color: '#94a3b8' }}>{src}</span>
                          <span style={{ color: '#f59e0b', fontWeight: 700 }}>{pct}%</span>
                        </div>
                        <div style={{ height: 6, background: '#1e293b', borderRadius: 3, overflow: 'hidden' }}>
                          <div style={{ width: pct + '%', height: '100%', background: '#f59e0b', borderRadius: 3 }} />
                        </div>
                      </div>
                    )
                  })}

                  <h3 style={{ margin: '20px 0 12px', fontSize: 14, fontWeight: 700, color: '#94a3b8' }}>Hot Leads 🔥</h3>
                  {contacts
                    .filter(c => c.score >= 75 && !['Completed', 'Lost'].includes(c.stage))
                    .sort((a, b) => b.score - a.score)
                    .slice(0, 3)
                    .map(c => (
                      <div key={c.id} onClick={() => setModal(c)} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #1e293b', cursor: 'pointer' }}>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700 }}>{c.name}</div>
                          <div style={{ fontSize: 11, color: '#64748b' }}>{c.stage}</div>
                        </div>
                        <ScoreBadge score={c.score} />
                      </div>
                    ))
                  }
                  {contacts.filter(c => c.score >= 75 && !['Completed', 'Lost'].includes(c.stage)).length === 0 && (
                    <div style={{ color: '#475569', fontSize: 13 }}>No hot leads yet.</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── BEST PRACTICES ── */}
          {view === 'bestpractices' && (
            <div style={{ maxWidth: 780 }}>
              <h1 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 800 }}>Solar Sales Best Practices</h1>
              <p style={{ color: '#64748b', marginBottom: 28, fontSize: 14 }}>Follow these guidelines to maximize close rates and customer satisfaction.</p>
              {[
                { icon: '⚡', title: 'Speed-to-Lead: Call Within 5 Minutes', body: "Studies show that contacting a lead within 5 minutes makes you 100x more likely to connect. Use this CRM to set a 'New Lead' task immediately on entry and assign it to a rep." },
                { icon: '📋', title: 'Always Log Every Touchpoint', body: "Update 'Last Contact' and notes after every call, email, or visit. A complete history lets any team member pick up seamlessly and shows the customer you're attentive." },
                { icon: '🏠', title: 'Complete a Site Survey Before Sending Proposals', body: 'A thorough site survey ensures accurate system sizing, roof assessment, shading analysis, and utility data — preventing costly redesigns or under-sized systems.' },
                { icon: '📊', title: 'Use Lead Scores to Prioritize Your Time', body: 'Score leads based on home ownership, utility bill size, roof age, interest level, and referral status. Focus top energy on leads scoring 70+. Re-engage cold leads monthly.' },
                { icon: '📄', title: 'Personalize Every Proposal', body: "Include the customer's actual roof layout, real utility savings estimates, local incentives (ITC, state credits, SRECs), and payback period. Generic proposals close at half the rate." },
                { icon: '🔁', title: 'Follow Up at Least 7 Times', body: '80% of sales require 5+ follow-ups. Use tasks in this CRM to schedule structured follow-ups at day 1, 3, 7, 14, and 30 after sending a proposal.' },
                { icon: '🤝', title: 'Ask for Referrals After Installation', body: 'The best time to ask is within 2 weeks of a completed install when satisfaction is highest. Offer a referral bonus and make it easy with a shareable link or card.' },
                { icon: '📅', title: 'Keep HOA & Permit Status Updated', body: 'Track HOA approval and permit status in the notes field. Delays here are the #1 reason deals fall through post-signature. Assign tasks with deadlines to stay on top.' },
                { icon: '🌟', title: 'Educate on Battery Storage Early', body: 'Introduce battery storage (e.g., Powerwall, Enphase) during the consultation phase, not after — it's much harder to upsell post-proposal. Bundle pricing increases close rate.' },
                { icon: '📉', title: "Nurture 'Lost' Leads — They Come Back", body: "Utility rates rise every year. Re-contact lost leads every 6–12 months with updated savings estimates. A 'no' today is often a 'yes' in 12 months." },
              ].map(({ icon, title, body }) => (
                <div key={title} style={{ display: 'flex', gap: 16, background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, padding: 20, marginBottom: 12 }}>
                  <div style={{ fontSize: 24, lineHeight: 1, marginTop: 2 }}>{icon}</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 6, color: '#f1f5f9' }}>{title}</div>
                    <div style={{ fontSize: 13, color: '#94a3b8', lineHeight: 1.6 }}>{body}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal */}
      {modal && (
        <Modal
          contact={modal === 'new' ? null : modal}
          onClose={() => setModal(null)}
          onSave={handleSave}
          onDelete={handleDelete}
          saving={saving}
        />
      )}

      {/* Toast */}
      {toast && <Toast message={toast.message} type={toast.type} />}

      <style>{`
        @keyframes spin { to { transform: rotate(360deg) } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>
    </div>
  )
}
